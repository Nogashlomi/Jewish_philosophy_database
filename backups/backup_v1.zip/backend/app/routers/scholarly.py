from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from rdflib import URIRef
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/scholarly", tags=["scholarly"])

@router.get("/")
async def list_scholarly(request: Request):
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    
    SELECT ?uri ?title ?year ?creatorName
    WHERE {
        ?uri a jp:ScholarlyWork ;
             jp:title ?title .
        OPTIONAL { ?uri jp:year ?year }
        OPTIONAL { ?uri jp:creatorName ?creatorName }
    }
    ORDER BY DESC(?year) ?title
    """
    
    results = []
    for row in rdf_store.query(q):
        results.append({
            "uri": row.uri,
            "id": row.uri.split("#")[-1],
            "title": row.title,
            "year": row.year,
            "creators": row.creatorName if row.creatorName else "-"
        })
        
    return templates.TemplateResponse("entity/scholarly_list.html", {
        "request": request,
        "works": results
    })

@router.get("/{work_id}")
async def scholarly_detail(request: Request, work_id: str):
    uri = URIRef(f"{JP}{work_id}")
    
    title = rdf_store.g.value(uri, JP.title)
    if not title:
         return templates.TemplateResponse("base.html", {"request": request, "error": "Work not found"})

    year = rdf_store.g.value(uri, JP.year)
    creator = rdf_store.g.value(uri, JP.creatorName)

    # Mentions Person
    mentions_person = []
    for p in rdf_store.g.objects(uri, JP.aboutPerson):
        label = rdf_store.g.value(p, RDFS.label)
        mentions_person.append({
            "id": p.split("#")[-1],
            "label": label
        })
        
    # Mentions Work
    mentions_work = []
    for w in rdf_store.g.objects(uri, JP.aboutWork):
        w_title = rdf_store.g.value(w, JP.title)
        mentions_work.append({
            "id": w.split("#")[-1],
            "title": w_title
        })

    return templates.TemplateResponse("entity/scholarly_detail.html", {
        "request": request,
        "work": {
            "uri": uri,
            "title": title,
            "year": year,
            "creator": creator,
            "mentions_person": mentions_person,
            "mentions_work": mentions_work
        }
    })
