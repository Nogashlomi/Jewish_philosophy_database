from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from rdflib import URIRef, Literal, BNode
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/persons", tags=["persons"])

@router.get("/")
async def list_persons(request: Request):
    # Query all persons
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?uri ?label ?work ?placeLabel ?timeVal ?sw
    WHERE {
        ?uri a jp:HistoricalPerson ;
             rdfs:label ?label .
        
        OPTIONAL { ?work jp:writtenBy ?uri }
        
        OPTIONAL { 
            ?uri jp:hasPlaceRelation ?pr .
            ?pr jp:relatedPlace ?place .
            ?place rdfs:label ?placeLabel .
        }

        OPTIONAL {
            ?uri jp:hasTimeRelation ?tr .
            ?tr jp:timeFrom ?trStart .
            OPTIONAL { ?tr jp:timeUntil ?trEnd }
            BIND( CONCAT(STR(?trStart), IF(BOUND(?trEnd), CONCAT("-", STR(?trEnd)), "")) as ?timeVal )
        }

        OPTIONAL { ?sw jp:aboutPerson ?uri }
    }
    ORDER BY ?label
    """
    
    # Python-side aggregation (Avoids rdflib GROUP_CONCAT issues)
    persons_map = {}
    for row in rdf_store.query(q):
        uri = str(row.uri)
        if uri not in persons_map:
            # Robust ID extraction
            persons_map[uri] = {
                "uri": row.uri,
                "id": uri.strip("/").split("/")[-1].split("#")[-1],
                "label": str(row.label),
                "works": set(),
                "places": set(),
                "times": set(),
                "mentions": set()
            }
        
        if row.work: persons_map[uri]["works"].add(row.work)
        if row.placeLabel: persons_map[uri]["places"].add(str(row.placeLabel))
        if row.timeVal: persons_map[uri]["times"].add(str(row.timeVal))
        if row.sw: persons_map[uri]["mentions"].add(row.sw)

    # Convert to list for template
    results = []
    for p in persons_map.values():
        p["workCount"] = len(p["works"])
        p["mentionCount"] = len(p["mentions"])
        p["places"] = ", ".join(sorted(p["places"])) if p["places"] else "-"
        p["times"] = ", ".join(sorted(p["times"])) if p["times"] else "-"
        results.append(p)
    
    # Sort by label
    results.sort(key=lambda x: x["label"])
        
    return templates.TemplateResponse("entity/person_list.html", {
        "request": request,
        "persons": results
    })

@router.get("/{person_id}")
async def person_detail(request: Request, person_id: str):
    uri = URIRef(f"{JP}{person_id}")
    
    # 1. Basic Info
    label = rdf_store.g.value(uri, RDFS.label)
    if not label:
        return templates.TemplateResponse("base.html", {"request": request, "error": "Person not found"})

    # 2. Authority Links
    authorities = list(rdf_store.g.objects(uri, JP.authorityLink))
    
    # 3. Authored Works
    q_works = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    SELECT ?work ?title
    WHERE {
        ?work jp:writtenBy ?person ;
              jp:title ?title .
    }
    """
    authored_works = []
    for row in rdf_store.query(q_works, initBindings={'person': uri}):
        authored_works.append({
            "uri": row.work,
            "id": row.work.split("#")[-1],
            "title": row.title
        })
        
    # 4. Scholarly Works about this person
    q_scholarly = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    SELECT ?sw ?title ?year
    WHERE {
        ?sw jp:aboutPerson ?person ;
            jp:title ?title .
        OPTIONAL { ?sw jp:year ?year }
    }
    """
    scholarly_mentions = []
    for row in rdf_store.query(q_scholarly, initBindings={'person': uri}):
        scholarly_mentions.append({
            "uri": row.sw,
            "id": row.sw.split("#")[-1],
            "title": row.title,
            "year": row.year
        })

    # 5. Place Relations
    q_places = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT ?rel ?place ?placeLabel ?type
    WHERE {
         ?person jp:hasPlaceRelation ?rel .
         ?rel jp:relatedPlace ?place ;
              jp:placeType ?type .
         ?place rdfs:label ?placeLabel .
    }
    """
    places = []
    for row in rdf_store.query(q_places, initBindings={'person': uri}):
        places.append({
            "place_uri": row.place,
            "place_id": row.place.split("#")[-1],
            "label": row.placeLabel,
            "type": row.type
        })

    # 6. Time Relations
    q_times = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT ?rel ?type ?start ?end
    WHERE {
         ?person jp:hasTimeRelation ?rel .
         ?rel jp:timeType ?type .
         OPTIONAL { ?rel jp:timeFrom ?start }
         OPTIONAL { ?rel jp:timeUntil ?end }
    }
    """
    times = []
    for row in rdf_store.query(q_times, initBindings={'person': uri}):
        times.append({
            "type": row.type,
            "start": row.start,
            "end": row.end
        })

    return templates.TemplateResponse("entity/person_detail.html", {
        "request": request,
        "person": {
            "id": person_id,
            "uri": uri,
            "label": label,
            "authorities": authorities,
            "works": authored_works,
            "scholarly": scholarly_mentions,
            "places": places,
            "times": times
        }
    })

# EDITING (Simple Update Label for now, illustrative of ability to edit)
@router.post("/{person_id}/save")
async def save_person(request: Request, person_id: str, label: str = Form(...)):
    uri = URIRef(f"{JP}{person_id}")
    
    # Update label
    rdf_store.g.set((uri, RDFS.label, Literal(label)))
    
    # (In a real app, we'd process all dynamic fields here)
    
    return RedirectResponse(url=f"/persons/{person_id}", status_code=303)

@router.post("/{person_id}/relations/place")
async def add_place_relation(
    request: Request, 
    person_id: str, 
    place_id: str = Form(...), 
    relation_type: str = Form(...)
):
    person_uri = URIRef(f"{JP}{person_id}")
    place_uri = URIRef(f"{JP}{place_id}")
    
    # Create a new blank node for the relation
    rel_node = BNode()
    
    # Add triples
    rdf_store.g.add((person_uri, JP.hasPlaceRelation, rel_node))
    rdf_store.g.add((rel_node, RDF.type, JP.PlaceRelation))
    rdf_store.g.add((rel_node, JP.relatedPlace, place_uri))
    rdf_store.g.add((rel_node, JP.placeType, Literal(relation_type))) # Using Literal for string property
    
    return RedirectResponse(url=f"/persons/{person_id}", status_code=303)

@router.post("/{person_id}/relations/time")
async def add_time_relation(
    request: Request, 
    person_id: str, 
    relation_type: str = Form(...), 
    start_year: str = Form(None), 
    end_year: str = Form(None)
):
    person_uri = URIRef(f"{JP}{person_id}")
    
    # Create a new blank node for the relation
    rel_node = BNode()
    
    # Add triples
    rdf_store.g.add((person_uri, JP.hasTimeRelation, rel_node))
    rdf_store.g.add((rel_node, RDF.type, JP.TimeRelation))
    rdf_store.g.add((rel_node, JP.timeType, Literal(relation_type)))
    
    if start_year:
        rdf_store.g.add((rel_node, JP.timeFrom, Literal(start_year))) # Assuming year is simple literal for now
    
    if end_year:
        rdf_store.g.add((rel_node, JP.timeUntil, Literal(end_year)))
        
    return RedirectResponse(url=f"/persons/{person_id}", status_code=303)

