from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from rdflib import URIRef
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/languages", tags=["languages"])

@router.get("/")
async def list_languages(request: Request):
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?uri ?label (COUNT(?work) as ?count)
    WHERE {
        ?uri a jp:HistoricalLanguage .
        OPTIONAL { ?uri rdfs:label ?label }
        OPTIONAL { ?work jp:writtenInLanguage ?uri }
    }
    GROUP BY ?uri ?label
    ORDER BY ?label
    """
    
    results = []
    for row in rdf_store.query(q):
        label = row.label if row.label else row.uri.split("#")[-1]
        results.append({
            "id": row.uri.split("#")[-1],
            "label": label,
            "count": row.count
        })
        
    return templates.TemplateResponse("entity/language_list.html", {
        "request": request,
        "languages": results
    })

@router.get("/{lang_id}")
async def language_detail(request: Request, lang_id: str):
    uri = URIRef(f"{JP}{lang_id}")
    
    label = rdf_store.g.value(uri, RDFS.label)
    if not label:
        label = lang_id
        
    # Get Works in this language
    q_works = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?work ?title
    WHERE {
        ?work jp:writtenInLanguage ?lang ;
              jp:title ?title .
    }
    ORDER BY ?title
    """
    
    works = []
    for row in rdf_store.query(q_works, initBindings={'lang': uri}):
        works.append({
            "id": row.work.split("#")[-1],
            "title": row.title
        })

    return templates.TemplateResponse("entity/language_detail.html", {
        "request": request,
        "language": {
            "label": label,
            "works": works
        }
    })
