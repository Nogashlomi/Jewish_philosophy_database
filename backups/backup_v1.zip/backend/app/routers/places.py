from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from app.core.rdf_store import rdf_store, JP, RDFS
from rdflib import URIRef, Literal # Added missing imports
from app.core.templates import templates

router = APIRouter(tags=["places"]) # Removed prefix to handle /places and /map and /api separately nicely

@router.get("/places")
async def list_places(request: Request):
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?uri ?label ?lat ?long (COUNT(DISTINCT ?person) as ?personCount)
    WHERE {
        ?uri a jp:Place ;
             rdfs:label ?label .
        OPTIONAL { ?uri jp:latitude ?lat ; jp:longitude ?long }
        OPTIONAL {
            ?person jp:hasPlaceRelation ?pr .
            ?pr jp:relatedPlace ?uri .
        }
    }
    GROUP BY ?uri ?label ?lat ?long
    ORDER BY ?label
    """
    results = []
    for row in rdf_store.query(q):
        results.append({
            "id": row.uri.split("#")[-1],
            "label": row.label,
            "lat": row.lat,
            "long": row.long,
            "personCount": row.personCount
        })
    return templates.TemplateResponse("entity/place_list.html", {"request": request, "places": results})

@router.get("/places/{place_id}")
async def place_detail(request: Request, place_id: str):
    
    uri = URIRef(f"{JP}{place_id}")
    
    label = rdf_store.g.value(uri, RDFS.label)
    if not label:
        return templates.TemplateResponse("base.html", {"request": request, "error": "Place not found"})
        
    # Get Persons associated with this place
    q_people = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?person ?personLabel ?type
    WHERE {
        ?person jp:hasPlaceRelation ?rel .
        ?person rdfs:label ?personLabel .
        ?rel jp:relatedPlace ?place ;
             jp:placeType ?type .
    }
    ORDER BY ?type ?personLabel
    """
    
    people = []
    for row in rdf_store.query(q_people, initBindings={'place': uri}):
        people.append({
            "id": row.person.split("#")[-1],
            "label": row.personLabel,
            "type": row.type
        })

    return templates.TemplateResponse("entity/place_detail.html", {
        "request": request,
        "place": {
            "uri": uri,
            "id": place_id,
            "label": label,
            "people": people
        }
    })


@router.get("/map")
async def map_view(request: Request):
    return templates.TemplateResponse("map.html", {"request": request})

@router.get("/api/geojson")
async def get_geojson():
    # We want markers for Persons at Places.
    # We also want time data for filtering.
    
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?person ?personLabel ?place ?placeLabel ?lat ?long ?pType ?start ?end
    WHERE {
        ?person a jp:HistoricalPerson ;
                rdfs:label ?personLabel ;
                jp:hasPlaceRelation ?pr .
        
        ?pr jp:relatedPlace ?place ;
            jp:placeType ?pType .
            
        ?place jp:latitude ?lat ;
               jp:longitude ?long ;
               rdfs:label ?placeLabel .
               
        # Try to find time range for the person (global approximation)
        OPTIONAL {
            ?person jp:hasTimeRelation ?tr .
            OPTIONAL { ?tr jp:timeFrom ?start }
            OPTIONAL { ?tr jp:timeUntil ?end }
        }
    }
    """
    
    features = []
    
    # helper to convert rdflib literals to python types
    def val(v): return str(v) if v else None
    
    for row in rdf_store.query(q):
        # We create a feature for this specific Person-Place connection
        # If a person has multiple time ranges, this might duplicate, but that's acceptable for now.
        
        start_year = val(row.start)
        end_year = val(row.end)
        
        # Clean years (sometimes they are xsd:gYear or strings)
        try: start_year = int(str(start_year).split("-")[0]) if start_year else None
        except: start_year = None
        try: end_year = int(str(end_year).split("-")[0]) if end_year else None
        except: end_year = None

        features.append({
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(row.long), float(row.lat)]
            },
            "properties": {
                "person_id": row.person.split("#")[-1],
                "person_label": val(row.personLabel),
                "place_label": val(row.placeLabel),
                "type": val(row.pType),
                "start": start_year,
                "end": end_year
            }
        })

    return JSONResponse({
        "type": "FeatureCollection",
        "features": features
    })
