from fastapi import APIRouter, Request, Depends
from fastapi.templating import Jinja2Templates
from app.core.rdf_store import rdf_store, JP, RDF
from app.core.templates import templates

router = APIRouter()

@router.get("/")
async def index(request: Request):
    # Calculate simple stats
    # NOTE: In a larger DB, we'd cache this or be careful. For 8900 triples, it's instant.
    
    stats_query = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT 
        (COUNT(DISTINCT ?p) as ?person_count)
        (COUNT(DISTINCT ?w) as ?work_count)
        (COUNT(DISTINCT ?sw) as ?scholarly_count)
        (COUNT(DISTINCT ?pl) as ?place_count)
    WHERE {
        { ?p a jp:HistoricalPerson . }
        UNION
        { ?w a jp:HistoricalWork . }
        UNION
        { ?sw a jp:ScholarlyWork . }
        UNION
        { ?pl a jp:Place . }
    }
    """
    
    # We run separate count queries for simplicity and safety against cross-product
    count_person = len(list(rdf_store.g.subjects(RDF.type, JP.HistoricalPerson)))
    count_works = len(list(rdf_store.g.subjects(RDF.type, JP.HistoricalWork)))
    count_scholarly = len(list(rdf_store.g.subjects(RDF.type, JP.ScholarlyWork)))
    count_places = len(list(rdf_store.g.subjects(RDF.type, JP.Place)))
    count_subjects = len(list(rdf_store.g.subjects(RDF.type, JP.Subject)))

    context = {
        "request": request,
        "counts": {
            "persons": count_person,
            "works": count_works,
            "scholarly": count_scholarly,
            "places": count_places,
            "subjects": count_subjects
        }
    }
    return templates.TemplateResponse("index.html", context)
