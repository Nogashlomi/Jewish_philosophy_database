from fastapi import APIRouter, Request, Depends
from fastapi.templating import Jinja2Templates
from rdflib import URIRef
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/subjects", tags=["subjects"])

@router.get("/")
async def list_subjects(request: Request):
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?uri ?label (COUNT(?work) as ?count)
    WHERE {
        ?uri a jp:Subject .
        OPTIONAL { ?uri rdfs:label ?label }
        OPTIONAL { ?work jp:hasSubject ?uri }
    }
    GROUP BY ?uri ?label
    ORDER BY ?label
    """
    
    results = []
    for row in rdf_store.query(q):
        label = row.label if row.label else row.uri.split("#")[-1]
        results.append({
            "id": row.uri.split("#")[-1],
            "label": label,
            "count": row.count
        })
        
    return templates.TemplateResponse("entity/subject_list.html", {
        "request": request,
        "subjects": results
    })

@router.get("/{subject_id}")
async def subject_detail(request: Request, subject_id: str):
    uri = URIRef(f"{JP}{subject_id}")
    
    label = rdf_store.g.value(uri, RDFS.label)
    if not label:
        label = subject_id
        
    # Get Works with this subject
    q_works = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?work ?title
    WHERE {
        ?work jp:hasSubject ?subject ;
              jp:title ?title .
    }
    ORDER BY ?title
    """
    
    works = []
    for row in rdf_store.query(q_works, initBindings={'subject': uri}):
        works.append({
            "id": row.work.split("#")[-1],
            "title": row.title
        })

    return templates.TemplateResponse("entity/subject_detail.html", {
        "request": request,
        "subject": {
            "label": label,
            "works": works
        }
    })
