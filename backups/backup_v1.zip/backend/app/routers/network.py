from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from rdflib import URIRef
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/network", tags=["network"])

@router.get("/network")
async def network_view(request: Request):
    return templates.TemplateResponse("network.html", {"request": request})

@router.get("/api/network")
async def get_network_data():
    nodes = set()
    edges = []
    
    # helper for clean IDs
    def mk_id(uri): return uri.strip("/").split("/")[-1].split("#")[-1]
    
    # 1. Fetch relevant triples (Limit to core entities to avoid noise)
    # Person, Work, ScholarlyWork, Place, Subject, Language
    
    # Query Nodes
    q_nodes = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?s ?label ?type
    WHERE {
        ?s a ?type .
        OPTIONAL { ?s rdfs:label ?label }
        FILTER (?type IN (jp:HistoricalPerson, jp:HistoricalWork, jp:ScholarlyWork, jp:Place, jp:Subject, jp:HistoricalLanguage))
    }
    """
    
    node_map = {} # uri -> {id, label, group}
    
    for row in rdf_store.query(q_nodes):
        nid = mk_id(row.s)
        etype = mk_id(row.type)
        label = row.label or nid
        
        node_map[row.s] = {
            "id": nid,
            "label": str(label),
            "group": etype
        }

    # Query Edges (Generic connectedness)
    # We explicitly look for specific relations to avoid meta-noise (like type definitions)
    # Relations: writtenBy, aboutPerson, aboutWork, hasSubject, writtenInLanguage, relatedPlace (via intermediate)
    
    # Simple direct relations
    q_direct = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT ?s ?o
    WHERE {
        ?s ?p ?o .
        FILTER (?p IN (
            jp:writtenBy, 
            jp:aboutPerson, 
            jp:aboutWork, 
            jp:hasSubject, 
            jp:writtenInLanguage
        ))
    }
    """
    for row in rdf_store.query(q_direct):
        if row.s in node_map and row.o in node_map:
            edges.append({"from": mk_id(row.s), "to": mk_id(row.o)})

    # Abstracted relations (Place)
    # Person -> hasPlaceRelation -> relatedPlace -> Place
    q_places = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT ?person ?place
    WHERE {
        ?person jp:hasPlaceRelation ?rel .
        ?rel jp:relatedPlace ?place .
    }
    """
    for row in rdf_store.query(q_places):
        if row.person in node_map and row.place in node_map:
             edges.append({"from": mk_id(row.person), "to": mk_id(row.place)})
             
    # Prepare list
    final_nodes = list(node_map.values())
    
    return JSONResponse({
        "nodes": final_nodes,
        "edges": edges
    })
