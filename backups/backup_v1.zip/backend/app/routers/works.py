from fastapi import APIRouter, Request, Depends
from fastapi.templating import Jinja2Templates
from rdflib import URIRef
from app.core.rdf_store import rdf_store, JP, RDF, RDFS
from app.core.templates import templates

router = APIRouter(prefix="/works", tags=["works"])

@router.get("/")
async def list_works(request: Request):
    q = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?uri ?title ?authorName ?sw
    WHERE {
        ?uri a jp:HistoricalWork ;
             jp:title ?title .
        OPTIONAL { 
            ?uri jp:writtenBy ?author . 
            ?author rdfs:label ?authorName .
        }
        OPTIONAL { ?sw jp:aboutWork ?uri }
    }
    ORDER BY ?title
    """
    
    # Python-side aggregation
    works_map = {}
    for row in rdf_store.query(q):
        uri = str(row.uri)
        if uri not in works_map:
            works_map[uri] = {
                "uri": row.uri,
                "id": uri.strip("/").split("/")[-1].split("#")[-1],
                "title": str(row.title),
                "authors": set(),
                "mentions": set()
            }
        if row.authorName: works_map[uri]["authors"].add(str(row.authorName))
        if row.sw: works_map[uri]["mentions"].add(row.sw)
    
    results = []
    for w in works_map.values():
        w["authors"] = ", ".join(sorted(w["authors"])) if w["authors"] else "-"
        w["mentionCount"] = len(w["mentions"])
        results.append(w)
        
    results.sort(key=lambda x: x["title"])
        
    return templates.TemplateResponse("entity/work_list.html", {
        "request": request,
        "works": results
    })

@router.get("/{work_id}")
async def work_detail(request: Request, work_id: str):
    uri = URIRef(f"{JP}{work_id}")
    
    title = rdf_store.g.value(uri, JP.title)
    if not title:
         return templates.TemplateResponse("base.html", {"request": request, "error": "Work not found"})

    # Authors
    authors = []
    for author_uri in rdf_store.g.objects(uri, JP.writtenBy):
        label = rdf_store.g.value(author_uri, RDFS.label)
        authors.append({
            "id": author_uri.split("#")[-1],
            "label": label
        })
        
    # Subjects
    subjects = []
    for subj_uri in rdf_store.g.objects(uri, JP.hasSubject):
        # Taking local name as label for subject if no RDFS label
        label = rdf_store.g.value(subj_uri, RDFS.label) or subj_uri.split("#")[-1]
        subjects.append(label)

    # Languages
    langs = []
    for lang_uri in rdf_store.g.objects(uri, JP.writtenInLanguage):
        label = rdf_store.g.value(lang_uri, RDFS.label) or lang_uri.split("#")[-1]
        langs.append(label)

    # Scholarly Mentions
    scholarly_mentions = []
    q_scholarly = """
    PREFIX jp: <http://jewish_philosophy.org/ontology#>
    SELECT ?sw ?title
    WHERE {
        ?sw jp:aboutWork ?work ;
            jp:title ?title .
    }
    """
    for row in rdf_store.query(q_scholarly, initBindings={'work': uri}):
        scholarly_mentions.append({
            "id": row.sw.split("#")[-1],
            "title": row.title
        })

    return templates.TemplateResponse("entity/work_detail.html", {
        "request": request,
        "work": {
            "uri": uri,
            "title": title,
            "authors": authors,
            "subjects": subjects,
            "languages": langs,
            "scholarly_mentions": scholarly_mentions
        }
    })
