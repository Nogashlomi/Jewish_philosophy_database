import os

class Settings:
    APP_NAME = "JPO Research Explorer"
    VERSION = "0.1.0"
    # Assuming running from backend/ directory (where main.py is executed via uvicorn)
    # data is in ../data relative to backend/
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # BASE_DIR should be backend/app/core/../../.. -> root
    # Actually, simpler: if running from `backend/`, data is `../data`
    
    # Let's use relative paths from execution context (backend/)
    DATA_DIR = os.path.join(os.getcwd(), "../data")
    ONTOLOGY_DIR = os.path.join(os.getcwd(), "../data/ontology")

settings = Settings()
