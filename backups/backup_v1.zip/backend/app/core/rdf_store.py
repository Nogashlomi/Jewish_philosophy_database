from pathlib import Path
from rdflib import Graph, Namespace, RDF, RDFS, OWL, SH

# Define Namespaces
JP = Namespace("http://jewish_philosophy.org/ontology#")

class RDFStore:
    def __init__(self):
        self.g = Graph()
        self.g.bind("jp", JP)
        self.g.bind("owl", OWL)
        self.g.bind("sh", SH)
        
    def load_data(self, root_dirs: list[str]):
        for root_dir in root_dirs:
            path = Path(root_dir)
            if not path.exists():
                print(f"Warning: Directory {root_dir} not found.")
                continue
            
            for file_path in path.rglob("*.ttl"):
                print(f"Loading {file_path}...")
                try:
                    self.g.parse(str(file_path), format="turtle")
                except Exception as e:
                    print(f"Error loading {file_path}: {e}")
        print(f"Graph loaded with {len(self.g)} triples.")

    def query(self, query_str: str, **kwargs):
        return self.g.query(query_str, **kwargs)

rdf_store = RDFStore()
