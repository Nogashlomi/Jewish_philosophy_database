from fastapi.templating import Jinja2Templates
import os

# Templates are in ../frontend/templates relative to the backend/ directory
# where the application is run from.
TEMPLATES_DIR = os.path.join(os.getcwd(), "../frontend/templates")
templates = Jinja2Templates(directory=TEMPLATES_DIR)
