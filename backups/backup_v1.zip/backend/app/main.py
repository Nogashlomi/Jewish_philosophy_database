from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.core.rdf_store import rdf_store
from app.core.config import settings
from app.routers import index, persons, works, scholarly, places, network, subjects, languages

# Initialize App
app = FastAPI(title=settings.APP_NAME, version=settings.VERSION)

from app.core.templates import templates

# Mount Static Files
app.mount("/static", StaticFiles(directory="../frontend/static"), name="static")

@app.on_event("startup")
async def startup_event():
    print("Starting up JPO Research Explorer...")
    rdf_store.load_data([settings.DATA_DIR, settings.ONTOLOGY_DIR])

app.include_router(index.router)
app.include_router(persons.router)
app.include_router(works.router)
app.include_router(scholarly.router)
app.include_router(places.router)
app.include_router(network.router)
app.include_router(subjects.router)
app.include_router(languages.router)

